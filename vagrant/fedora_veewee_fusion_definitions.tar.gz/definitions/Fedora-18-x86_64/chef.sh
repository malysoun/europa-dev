curl -L https://www.opscode.com/chef/install.sh | bash
