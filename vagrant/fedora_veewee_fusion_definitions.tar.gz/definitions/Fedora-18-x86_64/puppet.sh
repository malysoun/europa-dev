# Install Puppet
yum -y install puppet facter
