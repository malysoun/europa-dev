# Install Ruby
yum -y install ruby ruby-devel rubygems

