wget -O - http://bootstrap.saltstack.org | sudo sh
